  // AST constructor functions

  #include <stdlib.h> // for malloc
  #include "ast.h" // AST header

Expr ast_integer(int v) 
{
	Expr node = (Expr) malloc(sizeof(struct _Expr));
	node->kind = E_INTEGER;
	node->attr.value = v;
	return node;
}

Expr ast_variable(char* c)
{
	Expr node = (Expr) malloc(sizeof(struct _Expr));
	node->kind = E_VARIABLE;
	node->attr.var = c;
	return node;
}

Expr ast_operation(int operator, Expr left, Expr right) 
{
	Expr node = (Expr) malloc(sizeof(struct _Expr));
	node->kind = E_OPERATION;
	node->attr.op.operator = operator;
	node->attr.op.left = left;
	node->attr.op.right = right;
	return node;
}

Expr ast_boolean(int operator, Expr left, Expr right) 
{
	Expr node = (Expr) malloc(sizeof(struct _Expr));
	node->kind = E_BOOLEAN;
	node->attr.opBool.operator = operator;
	node->attr.opBool.left = left;
	node->attr.opBool.right = right;
	return node;
}

ExprList ast_exprlist(Expr expr, ExprList next)
{
	ExprList node = (ExprList) malloc(sizeof(struct _ExprList));
	node->head=expr;
	node->tail=next;
	return node;

}

cmdList ast_cmdlist(cmd command, cmdList next)
{
	cmdList node = (cmdList) malloc(sizeof(struct _cmdList));
	node->head = command;
	node->tail = next;
	return node;
}

cmd ast_atrib(char* v, Expr e)
{
	cmd node = (cmd) malloc(sizeof(struct _cmd));
	node->kind = C_ATRIB;
	node->un.atr.var = v;
	node->un.atr.exp = e;
	return node;
}

cmd ast_iff(Expr cond, cmdList list)
{
	cmd node = (cmd) malloc(sizeof(struct _cmd));
	node->kind = C_IF;
	node->un.iff.cond = cond;
	node->un.iff.list = list;
	return node;

}
cmd ast_elsee(cmdList list)
{
	cmd node = (cmd) malloc(sizeof(struct _cmd));
	node->kind = C_ELSE;
	node->un.elsee.list = list;
	return node;

}

cmd ast_fore(cmd decl, Expr condi, cmd incr, cmdList list)
{
	cmd node = (cmd) malloc(sizeof(struct _cmd));
	node->kind = C_FOR;
	node->un.fore.decl = decl;
	node->un.fore.condi = condi;
	node->un.fore.incr = incr;
	node->un.fore.list = list;
	return node;
}

cmd ast_whilee( Expr condi,  cmdList list)
{
	cmd node = (cmd) malloc(sizeof(struct _cmd));
	node->kind = C_WHILE;
	node->un.whilee.condi = condi;
	node->un.whilee.list = list;
	return node;
}

cmd ast_input(char *v)
{
	cmd node = (cmd) malloc(sizeof(struct _cmd));
	node->kind = C_INPUT;
	node->un.input = v;
	return node;
}

func ast_Func(char * func_n, cmdList body)
{
	func node = (func) malloc(sizeof(struct _func));
	node->var = func_n;
	node->body = body;
	return node;      
}

funcList ast_Function(func first, funcList funcs)
{
	funcList node = (funcList) malloc(sizeof(struct _funcList));
	node->head = first;
	node->tail = funcs;
	return node;  

}

