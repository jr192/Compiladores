
// AST definitions
#ifndef __ast_h__
#define __ast_h__

// AST for expressions
typedef struct _Expr 
{
	enum 
	{ 
		E_INTEGER,
		E_VARIABLE,
		E_OPERATION,
		E_BOOLEAN,
	} kind;
	union 
	{
		int value; 
		char* var;

		struct 
		{ 
			int operator; 
			struct _Expr* left;
			struct _Expr* right;
		} op; 

		struct 
		{ 
			int operator;
			struct _Expr* left;
			struct _Expr* right;
		} opBool;

	}attr;
}* Expr;

typedef struct _ExprList
{
	Expr head;
	struct _ExprList *tail;
}* ExprList;



typedef struct _cmd 
{
	enum { 
		C_ATRIB,
		C_IF,
		C_ELSE,
		C_FOR,
		C_WHILE,
		C_INPUT
	} kind;
	
	union 
	{
		struct 
		{
			char *var;
			Expr exp;
		} atr;

		struct
		{
			Expr cond;
			struct _cmdList* list;
		} iff;

		struct
		{
			struct _cmdList* list;
		} elsee;

		struct 
		{
			struct _cmd* decl;
			Expr condi;
			struct _cmd* incr;
			struct _cmdList* list;
		}fore;

		struct 
		{
			Expr condi; 
			struct _cmdList* list;
		}whilee;
		char *input;
	} un;
}* cmd;

typedef struct _cmdList
{
	cmd head;
	struct _cmdList *tail;
}* cmdList;

typedef struct _func 
{
	char *var;
	struct _cmdList* body;      
} *func;

typedef struct _funcList 
{
	func head;
	struct _funcList *tail;
}* funcList;


// Constructor functions (see implementation in ast.c)
Expr ast_integer(int v);
Expr ast_variable(char* c);
Expr ast_operation(int operator, Expr left, Expr right);
Expr ast_boolean(int operator, Expr left, Expr right);
ExprList ast_exprlist(Expr expr, ExprList next);
cmdList ast_cmdlist(cmd command, cmdList next);
cmd ast_atrib(char* v, Expr e);
cmd ast_iff(Expr cond, cmdList list);
cmd ast_elsee(cmdList list);
cmd ast_fore(cmd decl, Expr condi, cmd incr, cmdList list);
cmd ast_whilee(Expr condi, cmdList list);
cmd ast_input(char* v);
func ast_Func(char * func_n, cmdList body);
funcList ast_Function(func first, funcList funcs);
#endif
