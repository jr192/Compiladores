#ifndef __code_h__
#define __code_h__

typedef enum
{
  C_ADDE,
  C_SUBE,
  C_DIVE,
  C_MULT,
  C_BRE
} Operator;

typedef enum
{
  C_INT,
  C_VAR,
} TypeAddr; 

typedef struct _Endereco
{
  TypeAddr kind;

  union
  {
    int val;
    char *var;
  } content;
  
} *Endereco;

typedef struct _Instr
{
  Operator op;
  Endereco eddr1, eddr2, eddr3;
} *Instr;


typedef struct _InstrList
{
        Instr inst;
        struct _InstrList *next;
} *InstrList;

typedef struct _Pair
{
        Endereco name;
        InstrList list;
} *Pair;

typedef struct _Stack
{
  char *var;
  struct _Stack *next;
} *Stack;

Endereco code_mkInt(int i);
Endereco code_mkChar(char *v);

Instr code_mkInstr(Operator op, Endereco e1, Endereco e2, Endereco e3);
InstrList code_mkInstrList(Instr head, InstrList tail);
Pair code_mkPair(Endereco a, InstrList inst);

InstrList append(InstrList l1, InstrList l2);
InstrList tail(InstrList l);
Instr last(InstrList l);
InstrList removeLast(InstrList list);

Stack code_mkPilha(char * v, Stack st);
int code_mkPilhaContent(char * v, Stack st);

#endif
