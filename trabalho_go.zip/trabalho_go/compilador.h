
int count_var = 0;
int count_jump = 0;

Stack pilha = NULL;

char* Create_var(){
	int temp;
	char c = 't';
	if(count_var>9){
		temp = count_var - 9;
		c = 's';
	}
	else if(count_var >16){
		count_var = 0;
		temp = count_var;
	}
	else
		temp = count_var;

	char *var = malloc(sizeof(int)+2); //char = 2 ints
	sprintf(var,"$%c%d", c, temp);

	count_var++;

	return var;
} 

char* Create_jump(){
	char *jump = malloc(sizeof(int) + 4);
	sprintf(jump, "jump%d", count_jump);
  
 	 count_jump++;  

  	return jump;
}

Pair Expression(Expr expr){
	   if (expr->kind == E_INTEGER) 
        {
                printf("%d", expr->attr.value);
        } 
}