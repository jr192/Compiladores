#include <stdio.h>
#include "parser.h"

void eval(Expr expr) 
{
	int result = 0;
	if (expr->kind == E_INTEGER) 
	{
		printf("%d", expr->attr.value);
	} 

	else if (expr->kind == E_VARIABLE) 
	{
		printf("%s", expr->attr.var);
	}

	else if (expr->kind == E_OPERATION) 
	{
		eval(expr->attr.op.left);
		switch (expr->attr.op.operator) 
		{
			case PLUS: 
			printf(" + ");
			break;

			case SUB:
			printf(" - ");      
			break;

			case MUL:
			printf(" * ");
			break;

			case DIV:
			printf(" / ");
			break;

			case MOD:
			printf(" %% ");
			break;

			default: yyerror("Unknown operator!");
		}
		eval(expr->attr.op.right);
	}

	else if (expr->kind == E_BOOLEAN) 
	{
		eval(expr->attr.opBool.left);
		switch (expr->attr.opBool.operator) 
		{
			case LESS: 
			printf(" < ");
			break;

			case LESSeq:
			printf(" <= ");      
			break;

			case GREAT:
			printf(" > ");
			break;

			case GREATeq:
			printf(" >= ");
			break;

			case EQUAL:
			printf(" == ");
			break;

			case NEQUAL:
			printf(" != ");
			break;

			case TRUEE:
			printf(" true ");
			break;

			case FALSEE:
			printf(" false ");
			break;

			default: yyerror("Unknown operator!");
		}
		eval(expr->attr.opBool.right);
	}
}

void command_list_fore(cmd command)
{
	if (command->kind == C_ATRIB) 
	{
		printf("%s = ", command->un.atr.var); 
		eval(command->un.atr.exp);
	} 
}

void tabs(int tab) 
{
	int i;
	for(i=0; i<tab; i++)
		printf("\t");
}

void command_list(cmd command, int tab) 
{
	tabs(tab);
	if (command->kind == C_ATRIB) 
	{
		printf("%s = ", command->un.atr.var); 
		eval(command->un.atr.exp);
		if(command->kind!=C_FOR)
			printf("\n");
	} 
	else if (command->kind == C_IF) 
	{
		printf("IF "); 
		eval(command->un.iff.cond);
		printf("\n");
		tabs(tab);
		printf("{\n");
		while(command->un.iff.list != NULL) 
		{
			command_list(command->un.iff.list->head, tab+1);
			command->un.iff.list = command->un.iff.list->tail;
		}
		tabs(tab);
		printf("}\n");
	}

	else if (command->kind == C_ELSE) 
	{
		printf("ELSE \n"); 
		tabs(tab);
		printf("{\n");
		while(command->un.elsee.list != NULL) 
		{
			command_list(command->un.elsee.list->head, tab+1);
			command->un.elsee.list = command->un.elsee.list->tail;
		}
		tabs(tab);
		printf("}\n");
	}  

	else if(command->kind == C_WHILE) 
	{
		printf("FOR ");
		eval(command->un.whilee.condi);
		printf("\n");
		tabs(tab);
		printf("{\n");
		while(command->un.whilee.list != NULL) 
		{
			command_list(command->un.whilee.list->head, tab+1);
			command->un.whilee.list = command->un.whilee.list->tail;
		}
		tabs(tab);
		printf("}\n");
	}

	else if (command->kind == C_FOR) 
	{
		printf("FOR "); 
		command_list_fore(command->un.fore.decl); 
		printf("; "); 
		eval(command->un.fore.condi);
		printf("; ");
		command_list(command->un.fore.incr, 0);
		tabs(tab);
		printf("{\n");
		while(command->un.fore.list!=NULL)
		{
			command_list(command->un.fore.list->head, tab+1);
			command->un.fore.list = command->un.fore.list->tail;
		}
		tabs(tab);
		printf("}\n");
	}

	else if (command->kind == C_INPUT) 
	{
		printf("fmt.Scan(&%s)\n", command->un.input);
	}
}

void functions(func fun) 
{
	printf("func %s()\n{\n",fun->var);
	while(fun->body != NULL) {
		command_list(fun->body->head,1);
		fun->body = fun->body->tail;
	}
	printf("}\n");
}

int main(int argc, char** argv) 
{
	--argc; ++argv;
	if (argc != 0) 
	{
		yyin = fopen(*argv, "r");
		if (!yyin) {
			printf("'%s': could not open file\n", *argv);
			return 1;
		}
	}

	if (yyparse() == 0) 
	{
		while(root != NULL) 
		{
			functions(root->head);
			root = root->tail;
		}
	}
	return 0;
}
